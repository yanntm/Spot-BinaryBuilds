// -*- coding: utf-8 -*-
// Copyright (C) by the Spot authors, see the AUTHORS file for details.
//
// This file is part of Spot, a model checking library.
//
// Spot is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 3 of the License, or
// (at your option) any later version.
//
// Spot is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
// License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <spot/misc/common.hh>
#include <spot/misc/_config.h>
#include <cassert>
#include <iosfwd>
#include <string>
#include <map>
#include <chrono>
#if __has_include(<sys/times.h>)
# include <sys/times.h>
#endif
#include <ctime>
#include <chrono>

namespace spot
{
  /// \ingroup misc_tools
  /// @{


  /// \brief A simple stopwatch
  struct stopwatch
  {
  protected:
    /// Clock type used by the stopwatch.
    typedef std::chrono::steady_clock clock;
    clock::time_point start_; ///< Recorded start time point.
  public:
    /// Marks the start of the measurement
    void start()
    {
      start_ = clock::now();
    }

    /// \brief Returns the elapsed duration in seconds.
    ///
    /// May be called multiple times, and will always return the
    /// duration since the last call to start().
    double stop()
    {
      auto t = clock::now();
      typedef std::chrono::duration<double> seconds;
      return std::chrono::duration_cast<seconds>(t - start_).count();
    }
  };

  /// A structure to record elapsed time in clock ticks.
  struct time_info
  {
    time_info()
      : utime(0), stime(0), cutime(0), cstime(0)
    {
    }
    clock_t utime;   ///< User time of the process.
    clock_t stime;   ///< System time of the process.
    clock_t cutime;  ///< User time of child processes.
    clock_t cstime;  ///< System time of child processes.
  };

  /// A timekeeper that accumulates intervals of time in a more detailed way.
  /// For instance, you can get the time spent with or without children
  /// processes.
  class timer
  {
  public:
    timer()
      : running(false)
    {
    }

    /// Start a time interval.
    void
    start()
    {
      SPOT_ASSERT(!running);
      running = true;
      wall_start_ = std::chrono::steady_clock::now();
#ifdef SPOT_HAVE_TIMES
      struct tms tmp;
      times(&tmp);
      start_.utime = tmp.tms_utime;
      start_.cutime = tmp.tms_cutime;
      start_.stime = tmp.tms_stime;
      start_.cstime = tmp.tms_cstime;
#else
      start_.utime = clock();
#endif
    }

    /// Stop a time interval and update the sum of all intervals.
    void
    stop()
    {
      auto end = std::chrono::steady_clock::now();
      wall_cumul_ += std::chrono::duration_cast
        <std::chrono::milliseconds>(end - wall_start_).count();
#ifdef SPOT_HAVE_TIMES
      struct tms tmp;
      times(&tmp);
      total_.utime += tmp.tms_utime - start_.utime;
      total_.cutime += tmp.tms_cutime - start_.cutime;
      total_.stime += tmp.tms_stime - start_.stime;
      total_.cstime += tmp.tms_cstime - start_.cstime;
#else
      total_.utime += clock() - start_.utime;
#endif
      SPOT_ASSERT(running);
      running = false;
    }

    /// \brief Return the user time of the current process (without children)
    /// of all accumulated interval.
    ///
    /// Any time interval that has been start()ed but not stop()ed
    /// will not be accounted for.
    clock_t
    utime() const
    {
      return total_.utime;
    }

    /// \brief Return the user time of children of all accumulated interval.
    ///
    /// Any time interval that has been start()ed but not stop()ed
    /// will not be accounted for.
    clock_t
    cutime() const
    {
      return total_.cutime;
    }

    /// \brief Return the system time of the current process (without children)
    /// of all accumulated interval.
    ///
    /// Any time interval that has been start()ed but not stop()ed
    /// will not be accounted for.
    clock_t
    stime() const
    {
      return total_.stime;
    }

    /// \brief Return the system time of children of all accumulated interval.
    ///
    /// Any time interval that has been start()ed but not stop()ed
    /// will not be accounted for.
    clock_t
    cstime() const
    {
      return total_.cstime;
    }

    /// Return accumulated CPU ticks for selected time components.
    ///
    /// Each boolean flag selects a component: user/system time of
    /// the current process (parent) or its children.
    clock_t get_uscp(bool user, bool system, bool children, bool parent) const
    {
      clock_t res = 0;

      if (user && parent)
        res += utime();

      if (user && children)
        res += cutime();

      if (system && parent)
        res += stime();

      if (system && children)
        res += cstime();

      return res;
    }

    /// \brief Whether the timer is running.
    bool
    is_running() const
    {
      return running;
    }

    /// \brief Return cumulative wall time
    ///
    /// When using multithreading the cpu time is not
    /// relevant and we have to deal with wall time to have an
    /// effective timer
    std::chrono::milliseconds::rep
    walltime() const
    {
      return wall_cumul_;
    }

  protected:
    time_info start_; ///< Start time of the current interval.
    time_info total_; ///< Accumulated time across all intervals.
    bool running;     ///< Whether the timer is currently running.
    /// Wall-clock start time of the current interval.
    std::chrono::steady_clock::time_point wall_start_;
    std::chrono::milliseconds::rep wall_cumul_ = 0; ///< Wall time sum.
  };

  // This function declared here must be implemented in each file
  // that includes this header, well, only if this operator is needed!
  inline std::ostream& operator<<(std::ostream& os, const timer& dt);

  /// \brief A map of timer, where each timer has a name.
  ///
  /// Timer_map also keeps track of the number of measures each timer
  /// has performed.
  class timer_map
  {
  public:

    /// \brief Start a timer with name \a name.
    ///
    /// The timer is created if it did not exist already.
    /// Once started, a timer should be either stop()ed or
    /// cancel()ed.
    void
    start(const std::string& name)
    {
      item_type& it = tm[name];
      it.first.start();
      ++it.second;
    }

    /// \brief Stop timer \a name.
    ///
    /// The timer must have been previously started with start().
    void
    stop(const std::string& name)
    {
      tm[name].first.stop();
    }

    /// \brief Cancel timer \a name.
    ///
    /// The timer must have been previously started with start().
    ///
    /// This cancel only the current measure.  (Previous measures
    /// recorded by the timer are preserved.)  When a timer that has
    /// not done any measure is canceled, it is removed from the map.
    void
    cancel(const std::string& name)
    {
      tm_type::iterator i = tm.find(name);
      if (SPOT_UNLIKELY(i == tm.end()))
        throw std::invalid_argument("timer_map::cancel(): unknown name");
      SPOT_ASSERT(0 < i->second.second);
      if (0 == --i->second.second)
        tm.erase(i);
    }

    /// Return the timer \a name.
    const spot::timer&
    timer(const std::string& name) const
    {
      tm_type::const_iterator i = tm.find(name);
      if (SPOT_UNLIKELY(i == tm.end()))
        throw std::invalid_argument("timer_map::timer(): unknown name");
      return i->second.first;
    }

    /// \brief Whether there is no timer in the map.
    ///
    /// If empty() returns true, then either no timer were ever
    /// started, or all started timers were canceled without
    /// completing any measure.
    bool
    empty() const
    {
      return tm.empty();
    }

    /// Format information about all timers in a table.
    SPOT_API std::ostream&
    print(std::ostream& os) const;

    /// \brief Remove information about all timers.
    void
    reset_all()
    {
      tm.clear();
    }

  protected:
    typedef std::pair<spot::timer, int> item_type; ///< Timer + count pair.
    typedef std::map<std::string, item_type> tm_type; ///< Timer map type.
    tm_type tm; ///< The map of named timers.
  };

  /// \brief Struct used to start and stop both timer and stopwatch clocks.
  typedef struct process_timer
  {
    /// Start both wall-clock and CPU timers.
    void start()
    {
      walltimer.start();
      cputimer.start();
    }
    // sw.stop() --> It always returns the duration since the last call to
    // start(). Therefore, it won't stop timing, moreover, it can be called
    // multiple times.
    /// Stop both timers and record elapsed times.
    void stop()
    {
      walltime_lap_ = walltimer.stop();
      cputimer.stop();
    }

    /// Return elapsed wall time in seconds since the last start().
    double walltime() const
    {
      return walltime_lap_;
    }

    /// Return accumulated CPU ticks for selected time components.
    clock_t cputime(bool user, bool system, bool children, bool parent) const
    {
      return cputimer.get_uscp(user, system, children, parent);
    }

  private:
    spot::timer cputimer;
    spot::stopwatch walltimer;
    double walltime_lap_ = 0;
  } process_timer;

  /// @}
}
