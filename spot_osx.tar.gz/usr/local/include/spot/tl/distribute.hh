// -*- coding: utf-8 -*-
// Copyright (C) by the Spot authors, see the AUTHORS file for details.
//
// This file is part of Spot, a model checking library.
//
// Spot is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 3 of the License, or
// (at your option) any later version.
//
// Spot is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
// License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <spot/tl/formula.hh>

namespace spot
{
  /// \ingroup tl_rewriting
  /// \brief Distribute X at the top-level of a formula
  ///
  /// Convert a formula like X(a | X(b | X(c & Xd)))
  /// into X(a) | XX(b) | (XXX(c) & XXXXd)
  ///
  /// If some of the X operators in the chain are X[!] (strong next),
  /// the corresponding operators in the output will be X[!] as well,
  /// making this transformation suitable for both LTL (infinite
  /// semantics) and LTLf (finite semantics).
  SPOT_API formula distribute_next(formula f);
}
