// -*- coding: utf-8 -*-
// Copyright (C) by the Spot authors, see the AUTHORS file for details.
//
// This file is part of Spot, a model checking library.
//
// Spot is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 3 of the License, or
// (at your option) any later version.
//
// Spot is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
// License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <bddx.h>
#include <list>
#include <spot/twa/twa.hh>

namespace spot
{
  /// \ingroup emptiness_check_algorithms
  /// \brief Stack of strongly connected components for the Tarjan-Couvreur
  /// emptiness-check algorithm.
  class SPOT_API scc_stack
  {
  public:
    /// \brief A strongly connected component with its index, accumulated
    /// acceptance marks, and remaining states.
    struct connected_component
    {
    public:
      /// \brief Construct an SCC entry with the given index.
      connected_component(int index = -1);

      /// Index of the SCC.
      int index;
      /// The union of all acceptance marks of transitions the
      /// connected component.
      acc_cond::mark_t condition;

      std::list<const state*> rem; ///< Remaining states in this SCC.
    };

    /// Stack a new SCC with index \a index.
    void push(int index);

    /// Access the top SCC.
    connected_component& top();

    /// Access the top SCC.
    const connected_component& top() const;

    /// Pop the top SCC.
    void pop();

    /// How many SCC are in stack.
    size_t size() const;

    /// The \c rem member of the top SCC.
    std::list<const state*>& rem();

    /// Purge all \c rem members.
    ///
    /// \return the number of elements cleared.
    unsigned clear_rem();

    /// Is the stack empty?
    bool empty() const;

    typedef std::list<connected_component> stack_type; ///< SCC stack type.
    stack_type s; ///< The underlying SCC stack storage.
  };
}
